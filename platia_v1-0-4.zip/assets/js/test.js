var body = "";

// $(document).ready(function(){
//   document.getElementById("contactUsMap").innerHTML = placeDetails.getPlaceName();
// });

function getPlaceName(){
  var name = "Platia Food Truck";
  // console.log(body.name);
  // return body.name;
  return name;
}

// platiaDetails = {
//   getPlaceName : function() {
//     return body.name;
//   }
// }

// module.exports = function() {
//   const https = require('https');
//     this.getJSON = function(url) {
//       https.get(url, res => {
//         res.setEncoding("utf8");
//         res.on("data", data => {
//           body += data;
//         });
//         res.on("end", () => {
//           body = JSON.parse(body);
//           console.log(body.status);
//         });
//       });
//       return body;
//     }
// }
