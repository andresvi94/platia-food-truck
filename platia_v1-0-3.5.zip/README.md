# Platia Food Truck Website


## Creator

## Copyright and License

Copyright 2017 Andrés Vinueza

Code released under the [MIT](LICENSE)
